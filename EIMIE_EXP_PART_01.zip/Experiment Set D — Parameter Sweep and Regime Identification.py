import numpy as np
import matplotlib.pyplot as plt

# PARAMETERS
N = 128
dt = 0.01
steps = 2000
B = 1.0
kappa = 1.0
M = 1.0

A_values = [-1.0, -0.5, 0.0, 0.5, 1.0]

def initialize():
    return 0.1 * np.random.randn(N, N)

def compute_entropy(phi):
    hist, _ = np.histogram(phi, bins=100, density=True)
    hist = hist[hist > 0]
    return -np.sum(hist * np.log(hist))

def run(A):
    phi = initialize()
    cumulative = 0
    prev_S = compute_entropy(phi)

    for _ in range(steps):
        laplacian = (
            np.roll(phi, 1, 0) + np.roll(phi, -1, 0) +
            np.roll(phi, 1, 1) + np.roll(phi, -1, 1) - 4*phi
        )

        mu = A*phi + B*phi**3 - kappa*laplacian
        phi += dt * M * laplacian * mu

        S = compute_entropy(phi)
        dS = abs(S - prev_S)
        cumulative += dS
        prev_S = S

    return cumulative

# RUN SWEEP
EIME_values = []

for A in A_values:
    eime = run(A)
    EIME_values.append(eime)

# NORMALIZE
EIME_values = np.array(EIME_values)
EIME_values /= np.max(EIME_values)

# PLOT
plt.figure()
plt.plot(A_values, EIME_values, marker='o')
plt.xlabel('Parameter A')
plt.ylabel('Normalized EIME')
plt.title('EIME vs Control Parameter')
plt.grid()
plt.show()