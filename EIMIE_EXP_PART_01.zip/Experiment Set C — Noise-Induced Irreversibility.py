import numpy as np
import matplotlib.pyplot as plt

# PARAMETERS
N = 128
dt = 0.01
steps = 2000
A = -1.0
B = 1.0
kappa = 1.0
M = 1.0
noise_amp = 0.01

def initialize():
    return 0.1 * np.random.randn(N, N)

def compute_entropy(phi):
    hist, _ = np.histogram(phi, bins=100, density=True)
    hist = hist[hist > 0]
    return -np.sum(hist * np.log(hist))

def compute_free_energy(phi):
    gradx = np.roll(phi, -1, axis=0) - phi
    grady = np.roll(phi, -1, axis=1) - phi
    grad2 = gradx**2 + grady**2
    return np.sum(0.5*A*phi**2 + 0.25*B*phi**4 + 0.5*kappa*grad2)

def run(with_noise=False):
    phi = initialize()

    S_list, F_list, EIME = [], [], []
    cumulative = 0
    prev_S = compute_entropy(phi)

    for _ in range(steps):
        laplacian = (
            np.roll(phi, 1, 0) + np.roll(phi, -1, 0) +
            np.roll(phi, 1, 1) + np.roll(phi, -1, 1) - 4*phi
        )

        mu = A*phi + B*phi**3 - kappa*laplacian

        noise = noise_amp * np.random.randn(N, N) if with_noise else 0

        phi += dt * M * laplacian * mu + noise

        S = compute_entropy(phi)
        F = compute_free_energy(phi)

        dS = abs(S - prev_S)
        cumulative += dS

        S_list.append(S)
        F_list.append(F)
        EIME.append(cumulative)

        prev_S = S

    return np.array(S_list), np.array(F_list), np.array(EIME)

# RUN
S1, F1, E1 = run(with_noise=False)
S2, F2, E2 = run(with_noise=True)

# NORMALIZE
F1 /= F1[0]
F2 /= F2[0]
E1 /= E1[-1]
E2 /= E2[-1]

# PLOTS
plt.figure()
plt.plot(F1, label="No Noise")
plt.plot(F2, label="With Noise")
plt.legend()
plt.title("Free Energy")

plt.figure()
plt.plot(E1, label="No Noise")
plt.plot(E2, label="With Noise")
plt.legend()
plt.title("EIME Comparison")

plt.show()
