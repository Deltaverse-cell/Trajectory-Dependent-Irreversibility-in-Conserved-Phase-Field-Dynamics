import numpy as np
import matplotlib.pyplot as plt

# PARAMETERS
N = 128
dt = 0.01
steps = 2000
A = -1.0
B = 1.0
kappa = 1.0
M = 1.0
noise_strength = 0.01

def initialize():
    return 0.1 * np.random.randn(N, N)

def compute_entropy(phi):
    hist, _ = np.histogram(phi, bins=100, density=True)
    hist = hist[hist > 0]
    return -np.sum(hist * np.log(hist))

def free_energy(phi):
    grad = (
        (np.roll(phi, 1, 0) - phi)**2 +
        (np.roll(phi, 1, 1) - phi)**2
    )
    return np.sum(0.5*A*phi**2 + 0.25*B*phi**4 + 0.5*kappa*grad)

def structure_peak(phi):
    phi_k = np.fft.fft2(phi)
    S_k = np.abs(phi_k)**2
    return np.max(S_k)

def run(stochastic=False):
    phi = initialize()

    EIME = []
    F = []
    S_peak = []

    cumulative = 0
    prev_S = compute_entropy(phi)

    for _ in range(steps):

        laplacian = (
            np.roll(phi, 1, 0) + np.roll(phi, -1, 0) +
            np.roll(phi, 1, 1) + np.roll(phi, -1, 1) - 4*phi
        )

        mu = A*phi + B*phi**3 - kappa*laplacian

        if stochastic:
            noise = noise_strength * np.random.randn(N, N)
        else:
            noise = 0

        phi += dt * M * laplacian * mu + noise

        # entropy → EIME
        S = compute_entropy(phi)
        dS = abs(S - prev_S)
        cumulative += dS
        prev_S = S
        EIME.append(cumulative)

        # free energy
        F.append(free_energy(phi))

        # structure
        S_peak.append(structure_peak(phi))

    return np.array(EIME), np.array(F), np.array(S_peak)

# RUN BOTH SYSTEMS
EIME_A, F_A, S_A = run(stochastic=False)
EIME_B, F_B, S_B = run(stochastic=True)

# NORMALIZE
EIME_A /= np.max(EIME_A)
EIME_B /= np.max(EIME_B)

F_A /= np.max(np.abs(F_A))
F_B /= np.max(np.abs(F_B))

S_A /= np.max(S_A)
S_B /= np.max(S_B)

# PLOTS

plt.figure()
plt.plot(F_A, label="Deterministic")
plt.plot(F_B, label="Stochastic")
plt.title("Free Energy Comparison")
plt.legend()
plt.grid()

plt.figure()
plt.plot(S_A, label="Deterministic")
plt.plot(S_B, label="Stochastic")
plt.title("Structure Factor Peak Comparison")
plt.legend()
plt.grid()

plt.figure()
plt.plot(EIME_A, label="Deterministic")
plt.plot(EIME_B, label="Stochastic")
plt.title("EIME Comparison")
plt.legend()
plt.grid()

plt.show()
