import numpy as np
import matplotlib.pyplot as plt

# PARAMETERS
N = 128
dt = 0.01
steps = 2000
A = -1.0
B = 1.0
kappa = 1.0
M = 1.0

def initialize():
    return 0.1 * np.random.randn(N, N)

def compute_entropy(phi):
    hist, _ = np.histogram(phi, bins=100, density=True)
    hist = hist[hist > 0]
    return -np.sum(hist * np.log(hist))

def structure_factor(phi):
    phi_k = np.fft.fft2(phi)
    S_k = np.abs(phi_k)**2
    return np.fft.fftshift(S_k)

def peak_value(S_k):
    return np.max(S_k)

# RUN
phi = initialize()

EIME = []
S_peak = []

cumulative = 0
prev_S = compute_entropy(phi)

for step in range(steps):

    laplacian = (
        np.roll(phi, 1, 0) + np.roll(phi, -1, 0) +
        np.roll(phi, 1, 1) + np.roll(phi, -1, 1) - 4*phi
    )

    mu = A*phi + B*phi**3 - kappa*laplacian
    phi += dt * M * laplacian * mu

    # Entropy → EIME
    S = compute_entropy(phi)
    dS = abs(S - prev_S)
    cumulative += dS
    prev_S = S
    EIME.append(cumulative)

    # Structure factor
    S_k = structure_factor(phi)
    S_peak.append(peak_value(S_k))

# NORMALIZE
EIME = np.array(EIME)
EIME /= np.max(EIME)

S_peak = np.array(S_peak)
S_peak /= np.max(S_peak)

# PLOTS

plt.figure()
plt.plot(EIME)
plt.xlabel("Time step")
plt.ylabel("Normalized EIME")
plt.title("EIME Evolution")
plt.grid()

plt.figure()
plt.plot(S_peak)
plt.xlabel("Time step")
plt.ylabel("Normalized Structure Factor Peak")
plt.title("Structure Evolution (Peak Intensity)")
plt.grid()

plt.show()
